CREATE DATABASE IF NOT EXISTS shopping_cart_db;
USE shopping_cart_db;

CREATE TABLE IF NOT EXISTS users (
  userid INT AUTO_INCREMENT PRIMARY KEY,
  name VARCHAR(100) NOT NULL,
  email VARCHAR(150) NOT NULL UNIQUE,
  password VARCHAR(255) NOT NULL,
  phone VARCHAR(15)
);

CREATE TABLE IF NOT EXISTS products (
  productid INT AUTO_INCREMENT PRIMARY KEY,
  productname VARCHAR(150) NOT NULL,
  category VARCHAR(100) NOT NULL,
  price DECIMAL(10,2) NOT NULL,
  stock INT NOT NULL DEFAULT 0,
  description TEXT
);

CREATE TABLE IF NOT EXISTS carts (
  cartid INT AUTO_INCREMENT PRIMARY KEY,
  userid INT NOT NULL,
  productid INT NOT NULL,
  quantity INT NOT NULL DEFAULT 1,
  addeddate DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  CONSTRAINT fk_cart_user FOREIGN KEY (userid) REFERENCES users(userid) ON DELETE CASCADE,
  CONSTRAINT fk_cart_product FOREIGN KEY (productid) REFERENCES products(productid) ON DELETE CASCADE,
  CONSTRAINT uq_user_product UNIQUE (userid, productid)
);

CREATE TABLE IF NOT EXISTS orders (
  orderid INT AUTO_INCREMENT PRIMARY KEY,
  userid INT NOT NULL,
  totalamount DECIMAL(10,2) NOT NULL,
  orderdate DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  CONSTRAINT fk_order_user FOREIGN KEY (userid) REFERENCES users(userid)
);

-- Sample products for testing
INSERT INTO products (productname, category, price, stock, description) VALUES
('Wireless Headphones', 'Electronics', 1499.00, 25, 'Comfortable wireless headphones with clear sound.'),
('Smart Watch', 'Electronics', 2299.00, 18, 'Smart watch with activity tracking and notifications.'),
('Casual Backpack', 'Fashion', 899.00, 30, 'Lightweight backpack for college and everyday use.'),
('Running Shoes', 'Footwear', 1799.00, 20, 'Comfortable shoes suitable for daily walking and running.'),
('Desk Lamp', 'Home', 649.00, 15, 'Modern LED desk lamp for study and work.')
ON DUPLICATE KEY UPDATE productname = VALUES(productname);
