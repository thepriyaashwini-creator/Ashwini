# ShopEase — Online Shopping Cart Management System

A professional multi-page shopping website built with HTML, CSS, JavaScript, Node.js, Express.js and MySQL. Product category illustrations are stored locally in `public/images`, so the site does not depend on remote image URLs.

## Website pages
- `index.html` — Home page and shopping categories
- `products.html` — Product catalogue with search and category filter; product cards appear side by side
- `cart.html` — Cart quantity update, remove and checkout
- `orders.html` — Customer order history
- `login.html` — Login and registration
- `admin.html` — Add products to the catalogue (classroom demo; not role-protected)

## Database tables
1. `users(userid, name, email, password, phone)`
2. `products(productid, productname, category, price, stock, description)`
3. `carts(cartid, userid, productid, quantity, addeddate)`
4. `orders(orderid, userid, totalamount, orderdate)`

## Requirements
Install Node.js (LTS) and MySQL Server / MySQL Workbench.

## Run in VS Code and Chrome
1. Extract the ZIP file.
2. Open the extracted `ShopEase_Online_Shopping_Cart_Project` folder in VS Code.
3. Open MySQL Workbench and run the complete `database.sql` file. It creates the database and four tables and inserts sample products.
4. Copy `.env.example` to a new file named `.env`. Enter your MySQL username and password.
5. Open VS Code Terminal in the project folder and run:
   ```bash
   npm install
   npm start
   ```
6. Keep the terminal running. Open Chrome and visit **http://localhost:3000**.

## Important
- Register a customer account before adding items to the cart or placing an order.
- Do not upload `.env` or `node_modules` to GitHub.
- The Manage page is a simple academic demonstration and is not protected with administrator roles.
- For production use, configure a strong session secret, HTTPS, secure cookies, CSRF protection, input validation and admin authorization.

## GitHub upload
Extract the ZIP and upload the project files and folders to your GitHub repository. Upload the `public` folder including `public/images`. Do not upload `node_modules` or `.env`.
