require("dotenv").config();
const express = require("express");
const session = require("express-session");
const bcrypt = require("bcryptjs");
const mysql = require("mysql2/promise");
const path = require("path");

const app = express();
const PORT = process.env.PORT || 3000;

// Render and other hosts run behind a reverse proxy.
if (process.env.NODE_ENV === "production") app.set("trust proxy", 1);

const pool = mysql.createPool({
  host: process.env.DB_HOST || "localhost",
  port: Number(process.env.DB_PORT || 3306),
  user: process.env.DB_USER || "root",
  password: process.env.DB_PASSWORD || "",
  database: process.env.DB_NAME || "shopping_cart_db",
  waitForConnections: true,
  connectionLimit: 10
});

app.use(express.json());
app.use(express.urlencoded({ extended: true }));
app.use(session({
  secret: process.env.SESSION_SECRET || "development_secret_change_me",
  resave: false,
  saveUninitialized: false,
  cookie: { httpOnly: true, sameSite: "lax", secure: process.env.NODE_ENV === "production", maxAge: 24 * 60 * 60 * 1000 }
}));
app.use(express.static(path.join(__dirname, "public")));

function requireLogin(req, res, next) {
  if (!req.session.user) return res.status(401).json({ message: "Please login first." });
  next();
}

app.get("/health", (req, res) => res.status(200).json({ status: "ok" }));

app.get("/api/me", (req, res) => res.json({ user: req.session.user || null }));

app.post("/api/register", async (req, res) => {
  try {
    const { name, email, password, phone } = req.body;
    if (!name || !email || !password) return res.status(400).json({ message: "Name, email and password are required." });
    if (password.length < 6) return res.status(400).json({ message: "Password must contain at least 6 characters." });
    const hash = await bcrypt.hash(password, 10);
    const [result] = await pool.execute(
      "INSERT INTO users (name,email,password,phone) VALUES (?,?,?,?)",
      [name.trim(), email.trim().toLowerCase(), hash, phone || null]
    );
    req.session.user = { userid: result.insertId, name: name.trim(), email: email.trim().toLowerCase() };
    res.status(201).json({ message: "Registration successful.", user: req.session.user });
  } catch (err) {
    if (err.code === "ER_DUP_ENTRY") return res.status(409).json({ message: "Email is already registered." });
    console.error(err); res.status(500).json({ message: "Could not register user." });
  }
});

app.post("/api/login", async (req, res) => {
  try {
    const { email, password } = req.body;
    const [rows] = await pool.execute("SELECT * FROM users WHERE email = ?", [(email || "").trim().toLowerCase()]);
    if (!rows.length || !(await bcrypt.compare(password || "", rows[0].password))) {
      return res.status(401).json({ message: "Invalid email or password." });
    }
    req.session.user = { userid: rows[0].userid, name: rows[0].name, email: rows[0].email };
    res.json({ message: "Login successful.", user: req.session.user });
  } catch (err) { console.error(err); res.status(500).json({ message: "Login failed." }); }
});

app.post("/api/logout", (req, res) => {
  req.session.destroy(() => res.json({ message: "Logged out." }));
});

app.get("/api/products", async (req, res) => {
  try {
    const [rows] = await pool.query("SELECT * FROM products ORDER BY productid DESC");
    res.json(rows);
  } catch (err) { console.error(err); res.status(500).json({ message: "Could not load products." }); }
});

app.post("/api/products", async (req, res) => {
  try {
    const { productname, category, price, stock, description } = req.body;
    if (!productname || !category || Number(price) < 0 || Number(stock) < 0) {
      return res.status(400).json({ message: "Enter valid product details." });
    }
    const [result] = await pool.execute(
      "INSERT INTO products (productname,category,price,stock,description) VALUES (?,?,?,?,?)",
      [productname, category, Number(price), Number(stock), description || ""]
    );
    res.status(201).json({ message: "Product added.", productid: result.insertId });
  } catch (err) { console.error(err); res.status(500).json({ message: "Could not add product." }); }
});

app.put("/api/products/:id", async (req, res) => {
  try {
    const { productname, category, price, stock, description } = req.body;
    const [result] = await pool.execute(
      "UPDATE products SET productname=?,category=?,price=?,stock=?,description=? WHERE productid=?",
      [productname, category, Number(price), Number(stock), description || "", req.params.id]
    );
    if (!result.affectedRows) return res.status(404).json({ message: "Product not found." });
    res.json({ message: "Product updated." });
  } catch (err) { console.error(err); res.status(500).json({ message: "Could not update product." }); }
});

app.delete("/api/products/:id", async (req, res) => {
  try {
    const [result] = await pool.execute("DELETE FROM products WHERE productid=?", [req.params.id]);
    if (!result.affectedRows) return res.status(404).json({ message: "Product not found." });
    res.json({ message: "Product deleted." });
  } catch (err) { console.error(err); res.status(500).json({ message: "Could not delete product." }); }
});

app.get("/api/cart", requireLogin, async (req, res) => {
  try {
    const [rows] = await pool.execute(
      `SELECT c.cartid,c.quantity,c.addeddate,p.productid,p.productname,p.price,p.stock,
       (c.quantity*p.price) AS subtotal
       FROM carts c JOIN products p ON c.productid=p.productid
       WHERE c.userid=? ORDER BY c.addeddate DESC`, [req.session.user.userid]
    );
    res.json(rows);
  } catch (err) { console.error(err); res.status(500).json({ message: "Could not load cart." }); }
});

app.post("/api/cart", requireLogin, async (req, res) => {
  const connection = await pool.getConnection();
  try {
    const userid = req.session.user.userid;
    const productid = Number(req.body.productid);
    const quantity = Math.max(1, Number(req.body.quantity) || 1);
    await connection.beginTransaction();
    const [products] = await connection.execute("SELECT stock FROM products WHERE productid=? FOR UPDATE", [productid]);
    if (!products.length) { await connection.rollback(); return res.status(404).json({ message: "Product not found." }); }
    const [existing] = await connection.execute("SELECT quantity FROM carts WHERE userid=? AND productid=?", [userid, productid]);
    const newQuantity = quantity + (existing[0]?.quantity || 0);
    if (newQuantity > products[0].stock) { await connection.rollback(); return res.status(400).json({ message: "Requested quantity exceeds available stock." }); }
    await connection.execute(
      `INSERT INTO carts (userid,productid,quantity) VALUES (?,?,?)
       ON DUPLICATE KEY UPDATE quantity=quantity+VALUES(quantity), addeddate=CURRENT_TIMESTAMP`,
      [userid, productid, quantity]
    );
    await connection.commit();
    res.status(201).json({ message: "Product added to cart." });
  } catch (err) { await connection.rollback(); console.error(err); res.status(500).json({ message: "Could not add to cart." }); }
  finally { connection.release(); }
});

app.put("/api/cart/:id", requireLogin, async (req, res) => {
  try {
    const quantity = Number(req.body.quantity);
    if (!Number.isInteger(quantity) || quantity < 1) return res.status(400).json({ message: "Quantity must be at least 1." });
    const [rows] = await pool.execute(
      `SELECT c.cartid,p.stock FROM carts c JOIN products p ON c.productid=p.productid
       WHERE c.cartid=? AND c.userid=?`, [req.params.id, req.session.user.userid]
    );
    if (!rows.length) return res.status(404).json({ message: "Cart item not found." });
    if (quantity > rows[0].stock) return res.status(400).json({ message: "Quantity exceeds available stock." });
    await pool.execute("UPDATE carts SET quantity=? WHERE cartid=? AND userid=?", [quantity, req.params.id, req.session.user.userid]);
    res.json({ message: "Cart updated." });
  } catch (err) { console.error(err); res.status(500).json({ message: "Could not update cart." }); }
});

app.delete("/api/cart/:id", requireLogin, async (req, res) => {
  try {
    await pool.execute("DELETE FROM carts WHERE cartid=? AND userid=?", [req.params.id, req.session.user.userid]);
    res.json({ message: "Item removed from cart." });
  } catch (err) { console.error(err); res.status(500).json({ message: "Could not remove item." }); }
});

app.post("/api/checkout", requireLogin, async (req, res) => {
  const connection = await pool.getConnection();
  try {
    const userid = req.session.user.userid;
    await connection.beginTransaction();
    const [items] = await connection.execute(
      `SELECT c.productid,c.quantity,p.price,p.stock,p.productname
       FROM carts c JOIN products p ON c.productid=p.productid
       WHERE c.userid=? FOR UPDATE`, [userid]
    );
    if (!items.length) { await connection.rollback(); return res.status(400).json({ message: "Your cart is empty." }); }
    for (const item of items) {
      if (item.quantity > item.stock) throw new Error(`${item.productname} does not have enough stock.`);
    }
    const total = items.reduce((sum, item) => sum + Number(item.price) * item.quantity, 0);
    const [order] = await connection.execute(
      "INSERT INTO orders (userid,totalamount) VALUES (?,?)", [userid, total.toFixed(2)]
    );
    for (const item of items) {
      await connection.execute("UPDATE products SET stock=stock-? WHERE productid=?", [item.quantity, item.productid]);
    }
    await connection.execute("DELETE FROM carts WHERE userid=?", [userid]);
    await connection.commit();
    res.status(201).json({ message: "Order placed successfully.", orderid: order.insertId, totalamount: total.toFixed(2) });
  } catch (err) {
    await connection.rollback();
    res.status(400).json({ message: err.message || "Checkout failed." });
  } finally { connection.release(); }
});

app.get("/api/orders", requireLogin, async (req, res) => {
  try {
    const [rows] = await pool.execute(
      "SELECT orderid,totalamount,orderdate FROM orders WHERE userid=? ORDER BY orderdate DESC",
      [req.session.user.userid]
    );
    res.json(rows);
  } catch (err) { console.error(err); res.status(500).json({ message: "Could not load orders." }); }
});

app.get("*", (req, res) => res.sendFile(path.join(__dirname, "public", "index.html")));

(async () => {
  try {
    await pool.query("SELECT 1");
    app.listen(PORT, () => console.log(`Shopping Cart app running at http://localhost:${PORT}`));
  } catch (err) {
    console.error("MySQL connection failed. Check your .env settings and import database.sql.", err.message);
    process.exit(1);
  }
})();
