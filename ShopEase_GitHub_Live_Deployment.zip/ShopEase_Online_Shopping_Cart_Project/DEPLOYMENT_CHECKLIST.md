# Deployment checklist

- [ ] Project files and `public/images` pushed to GitHub
- [ ] `.env` and `node_modules` are NOT in GitHub
- [ ] Managed MySQL database created
- [ ] `database.sql` imported; four tables visible
- [ ] MySQL accepts connections from the web host
- [ ] Render environment variables configured
- [ ] Deployment succeeds and `/health` returns `{"status":"ok"}`
- [ ] Website tested in Chrome: register, login, browse products, cart, checkout, orders
- [ ] No real payment details or real customer data used in this demo
