# ShopEase – Online Shopping Cart Management System

## 1. Project Description

ShopEase is a multi-page online shopping cart management website developed as an academic mini project. It allows customers to register and log in, browse products, search and filter the catalogue, add products to a shopping cart, change quantities, remove items, complete checkout, and view their order history. The project also includes a simple product-management page for adding products to the catalogue.

The interface is designed like a modern shopping website. It uses separate pages for Home, Products, Cart, Orders, Login/Register and Manage Products. Product cards are arranged side by side in a responsive grid, and locally stored category illustrations are included in `public/images`.

## 2. Technologies Used

- **Frontend:** HTML5, CSS3 and JavaScript
- **Backend:** Node.js and Express.js
- **Database:** MySQL
- **Authentication:** Password hashing with bcrypt
- **Development tools:** Visual Studio Code, MySQL Workbench and Google Chrome

## 3. Main Modules / Website Pages

| Page / Module | Description |
|---|---|
| Home | Displays the store introduction, shopping categories and featured products. |
| Products | Displays the product catalogue with search and category filtering. |
| Cart | Shows selected products, allows quantity changes and item removal, and supports checkout. |
| Orders | Displays the logged-in customer's order history. |
| Login / Register | Allows a customer to create an account and sign in. |
| Manage Products | Provides a simple academic demonstration interface for adding products. |

## 4. Database Details

**Database name:** `shopping_cart_db`

The database contains four main tables: `users`, `products`, `carts`, and `orders`.

### Table 1: `users`
**Purpose:** Stores customer registration and account details.

| Field name | Data type | Key / Constraint | Description |
|---|---|---|---|
| `userid` | INT, AUTO_INCREMENT | PRIMARY KEY | Unique ID assigned to each customer. |
| `name` | VARCHAR(100) | NOT NULL | Customer's full name. |
| `email` | VARCHAR(150) | UNIQUE, NOT NULL | Customer's email address used for login. |
| `password` | VARCHAR(255) | NOT NULL | Hashed customer password. |
| `phone` | VARCHAR(15) | Optional | Customer's phone number. |

### Table 2: `products`
**Purpose:** Stores the products available in the online store.

| Field name | Data type | Key / Constraint | Description |
|---|---|---|---|
| `productid` | INT, AUTO_INCREMENT | PRIMARY KEY | Unique ID for each product. |
| `productname` | VARCHAR(150) | NOT NULL | Name of the product. |
| `category` | VARCHAR(100) | NOT NULL | Product category, such as Electronics or Fashion. |
| `price` | DECIMAL(10,2) | NOT NULL | Product price with two decimal places. |
| `stock` | INT | NOT NULL, DEFAULT 0 | Number of units currently available. |
| `description` | TEXT | Optional | Detailed information about the product. |

### Table 3: `carts`
**Purpose:** Stores products selected by customers before checkout.

| Field name | Data type | Key / Constraint | Description |
|---|---|---|---|
| `cartid` | INT, AUTO_INCREMENT | PRIMARY KEY | Unique ID for each cart record. |
| `userid` | INT | FOREIGN KEY → `users.userid` | Identifies the customer who owns the cart item. |
| `productid` | INT | FOREIGN KEY → `products.productid` | Identifies the selected product. |
| `quantity` | INT | NOT NULL, DEFAULT 1 | Number of units selected. |
| `addeddate` | DATETIME | NOT NULL, DEFAULT CURRENT_TIMESTAMP | Date and time when the item was added. |

**Additional constraint:** `UNIQUE(userid, productid)` prevents the same product from appearing in multiple separate rows for one customer; its quantity is updated instead. The foreign keys use `ON DELETE CASCADE` so related cart rows are removed when their referenced user or product is deleted.

### Table 4: `orders`
**Purpose:** Stores completed customer order summaries.

| Field name | Data type | Key / Constraint | Description |
|---|---|---|---|
| `orderid` | INT, AUTO_INCREMENT | PRIMARY KEY | Unique ID for each order. |
| `userid` | INT | FOREIGN KEY → `users.userid` | Identifies the customer who placed the order. |
| `totalamount` | DECIMAL(10,2) | NOT NULL | Total amount charged for the order. |
| `orderdate` | DATETIME | NOT NULL, DEFAULT CURRENT_TIMESTAMP | Date and time when the order was placed. |

## 5. Table Relationships

- One user can have many cart records: `users.userid` → `carts.userid`.
- One product can appear in many customers' carts: `products.productid` → `carts.productid`.
- One user can place many orders: `users.userid` → `orders.userid`.

**Relationship summary:** `users` 1-to-many `carts`; `products` 1-to-many `carts`; `users` 1-to-many `orders`.

## 6. Main Workflow

1. A customer registers or logs in.
2. The customer browses, searches or filters products.
3. The customer adds a product to the cart and selects a quantity.
4. The system checks available stock.
5. The customer proceeds to checkout.
6. The system creates an order, updates stock and clears the purchased cart items.
7. The customer can view the order in the Orders page.

## 7. How to Run the Project

1. Install Node.js LTS and MySQL Server.
2. Extract the ZIP and open the `ShopEase_Online_Shopping_Cart_Project` folder in VS Code.
3. Open MySQL Workbench and execute `database.sql` to create `shopping_cart_db`, its four tables and sample products.
4. Copy `.env.example` to `.env` and enter the correct MySQL host, username, password and database settings.
5. Open the VS Code terminal in the project folder and run `npm install`.
6. Run `npm start` and keep the terminal open.
7. Open Google Chrome and visit `http://localhost:3000`.

## 8. Expected Outcome

A responsive multi-page shopping website where users can browse products, manage a cart and place orders, with customer, product, cart and order information stored in MySQL.

## 9. Limitations

This is an educational mini project. The product-management page is a demonstration and does not include full administrator role authorization. A production deployment would require additional security controls, payment-gateway integration, delivery management, HTTPS and stronger operational monitoring.
